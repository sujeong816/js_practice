let a = [1,2,3,4];

let [i, j, k, l] = a;
console.log(l, i, j, k)