function factory() {
    const width = 4, height = 5;
    console.log(width*height)
}

// let func = factory();
factory();