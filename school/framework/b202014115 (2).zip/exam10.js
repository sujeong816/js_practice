function merge(...arr) {
    let a = arr.push(arr)
    return arr;
}

console.log(merge([1, 2])); 
console.log(merge([1, 2], [3, 4, 5])); 
console.log(merge([1, 2], [3, 4], [5, 6], [7]));