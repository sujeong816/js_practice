let p1={name: "홍길동", age: 16}

let p2 = {...p1}

console.log(p1==p2)
console.log(p2)