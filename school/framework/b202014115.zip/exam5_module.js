export function add(i, j) {
    return i+j;
}

export function multiply(i, j) {
    return i*j;
}