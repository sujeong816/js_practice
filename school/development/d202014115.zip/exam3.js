// types 함수 구현 
function types(...arr) {
    let res = [];
    res = arr.map(i=>res.push(typeof i))
    return res;
}
console.log(types([3, "hello", true])); 
console.log(types(["world", []]));