function print(str) {
    console.log(typeof str);
}
print(true); 
print("hello world"); 
print();