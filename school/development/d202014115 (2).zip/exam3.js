// types 함수 구현 
function types(...arr) {
    let res = [];
    for(let i=0; i<arr.length; i++) {
        res.push(typeof i);
    }
    return res;
}
console.log(types([3, "hello", true])); 
console.log(types(["world", []]));